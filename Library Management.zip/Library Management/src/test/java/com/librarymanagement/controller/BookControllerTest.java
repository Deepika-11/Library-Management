package com.librarymanagement.controller;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.librarymanagement.entity.Author;
import com.librarymanagement.entity.Book;
import com.librarymanagement.exceptionHandling.BookIsbnExistsOrNot;
import com.librarymanagement.serviceImpl.BookServiceImpl;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import static org.mockito.Mockito.when;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@WebMvcTest(BookController.class)
public class BookControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private BookServiceImpl bookService;

    @InjectMocks
    private BookController bookController;

    @Autowired
    private ObjectMapper objectMapper;

    Author author1;
    Author author2;
    Book book1;
    Book book2;
    List<Author> authorList = new ArrayList<>();

    List<Book> bookList = new ArrayList<>();

    @BeforeEach
    void setUp() {

        author1 = new Author(123L,"Robbin Hood", LocalDate.of(2017, 1, 13));
        author2 = new Author(456L,"Rohit Sharma", LocalDate.of(2000, 5, 10));
        authorList.add(author1);
        authorList.add(author2);
        book1 = new Book(1234567890L, "The 5 AM Club",LocalDate.of(2017, 1, 13),2345.90, authorList);
        book2 = new Book(12345678L, "Power of Your Subconscious",LocalDate.of(2019, 1, 13),2341.90, authorList);
        bookList.add(book1);
        bookList.add(book2);
    }

    @AfterEach
    void tearDown() {
    }

    @Test
    public void testSaveBookDetail() throws Exception {

        when(bookService.findBookExistsOrNot(book1)).thenReturn(false);
        when(bookService.findAuthorIdExistsOrNotFOrBook(book1)).thenReturn(true);

        mockMvc.perform(post("/books/save")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(book1)))
                .andExpect(status().isCreated());

    }


    @Test
    public void testGetBookDetailsSuccessAndFailure() throws Exception {
        Long isbn = 123456789L;

        when(bookService.getBookByIsbn(isbn)).thenReturn(Optional.of(book1));

        mockMvc.perform(get("/books/get/{isbn}", isbn))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.title").value("The 5 AM Club"));

        String errorMessage = "The given book is not found. So necessary operation is not able to do.";

        when(bookService.getBookByIsbn(isbn)).thenReturn(Optional.empty());


        mockMvc.perform(get("/books/get/{isbn}", isbn))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.errorResponse").value(errorMessage))
                .andExpect(result -> assertTrue(result.getResolvedException() instanceof BookIsbnExistsOrNot));
    }


    @Test
    public void testUpdateBookDetailsSuccessAndFailure() throws Exception {
        Long isbn = 123456789L;

        when(bookService.getBookByIsbn(isbn)).thenReturn(Optional.of(book2));

        mockMvc.perform(put("/books/update/{isbn}", isbn)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(book1)))
                .andExpect(status().isOk());

        isbn = 987654321L;

        String errorMessage = "The given book is not found. So necessary operation is not able to do.";

        when(bookService.getBookByIsbn(isbn)).thenReturn(Optional.empty());

        mockMvc.perform(put("/books/update/{isbn}", isbn)
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(book1)))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.errorResponse").value(errorMessage))
                .andExpect(result -> assertTrue(result.getResolvedException() instanceof BookIsbnExistsOrNot));
    }

    @Test
    public void testDeleteBookByIsbnSuccessAndFailure() throws Exception {
        Long isbn = 123456789L;

        // Mock the bookService to return an Optional containing a book
        when(bookService.getBookByIsbn(isbn)).thenReturn(Optional.of(book2));

        mockMvc.perform(delete("/books/delete/{isbn}", isbn))
                .andExpect(status().isOk());

        isbn = 987654321L;

        String errorMessage = "The given book is not found. So necessary operation is not able to do.";

        // Mock the bookService to return an empty Optional
        when(bookService.getBookByIsbn(isbn)).thenReturn(Optional.empty());

        mockMvc.perform(delete("/books/delete/{isbn}", isbn))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.errorResponse").value(errorMessage))
                .andExpect(result -> assertTrue(result.getResolvedException() instanceof BookIsbnExistsOrNot));
    }


}
