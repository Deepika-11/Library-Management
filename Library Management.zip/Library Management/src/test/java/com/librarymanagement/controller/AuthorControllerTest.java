package com.librarymanagement.controller;


import com.fasterxml.jackson.databind.ObjectMapper;
import com.librarymanagement.entity.Author;
import com.librarymanagement.entity.Book;
import com.librarymanagement.exceptionHandling.AuthorExistsOrNotException;
import com.librarymanagement.exceptionHandling.BookIsbnExistsOrNot;
import com.librarymanagement.serviceImpl.AuthorServiceImpl;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import java.time.LocalDate;
import java.util.*;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(AuthorController.class)
public class AuthorControllerTest {

        @Autowired
        private MockMvc mockMvc;

        @MockBean
        private AuthorServiceImpl authorService;

        @InjectMocks
        private AuthorController authorController;

        @Autowired
        private ObjectMapper objectMapper;


        Author author1;
        Author author2;
        Book book1;
        Book book2;
        List<Author> authorList = new ArrayList<>();

        List<Book> bookList = new ArrayList<>();

        @BeforeEach
        void setUp() {
            author1 = new Author(123L,"Robbin Hood", LocalDate.of(2017, 1, 13));
            author2 = new Author(456L,"Rohit Sharma", LocalDate.of(2000, 5, 10));
            authorList.add(author1);
            authorList.add(author2);
            book1 = new Book(1234567890L, "The 5 AM Club",LocalDate.of(2017, 1, 13),2345.90, authorList);
            book2 = new Book(12345678L, "Power of Your Subconscious",LocalDate.of(2019, 1, 13),2341.90, authorList);
            bookList.add(book1);
            bookList.add(book2);
        }

        @AfterEach
        void tearDown() {
        }

        @Test
        public void testSaveAuthorDetails() throws Exception {

            when(authorService.findAuthorExistsOrNot(author1)).thenReturn(false);
            when(authorService.save(author1)).thenReturn(author1);

            mockMvc.perform(MockMvcRequestBuilders.post("/authors/save")
                            .contentType(MediaType.APPLICATION_JSON)
                            .content(objectMapper.writeValueAsString(author1)))
                    .andDo(print()).andExpect(status().isCreated());
        }

        @Test
        public void getAuthorById() throws Exception {

            Long authorId = 1L;

            when(authorService.findAuthorIdExistsOrNot(authorId)).thenReturn(Optional.of(author1));

            this.mockMvc.perform(get("/authors/get/{id}", authorId))
                    .andDo(print()).andExpect(status().isOk());

        }

        @Test
        public void deleteAuthorById() throws Exception {
            // Test for successful deletion of author by ID
            Long authorId = 1L;

            when(authorService.findAuthorIdExistsOrNot(authorId)).thenReturn(Optional.of(author1));
            when(authorService.deleteAuthor(authorId)).thenReturn("");

            this.mockMvc.perform(delete("/authors/delete/{id}", authorId))
                    .andExpect(status().isOk());

            // Test for failure deletion of author by ID

            Long invalidAuthorId = 999L;
            String errorMessage = "The given author is not found. So necessary operation is not able to do.";
            when(authorService.findAuthorIdExistsOrNot(invalidAuthorId)).thenReturn(Optional.empty());

            mockMvc.perform(delete("/authors/delete/{id}", invalidAuthorId))
                    .andExpect(status().isNotFound())
                    .andExpect(jsonPath("$.errorResponse").value(errorMessage))
                    .andExpect(result -> assertTrue(result.getResolvedException() instanceof AuthorExistsOrNotException));
        }

        @Test
        public void getAllBookByAuthor() throws Exception {
            Long authorId = 1L;

            when(authorService.findAuthorIdExistsOrNot(authorId)).thenReturn(Optional.of(author1));
            when(authorService.getBooksByAuthor(author1)).thenReturn(bookList);

            mockMvc.perform(get("/authors/get/list/{id}", authorId))
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$.length()").value(bookList.size()));


            Long invalidAuthorId = 999L;
            String errorMessage = "Author id doesn't exists";
            when(authorService.findAuthorIdExistsOrNot(invalidAuthorId)).thenReturn(Optional.empty());

            mockMvc.perform(get("/authors/get/list/{id}", invalidAuthorId))
                    .andExpect(status().isNotFound())
                    .andExpect(jsonPath("$.errorResponse").value(errorMessage));
        }
}
