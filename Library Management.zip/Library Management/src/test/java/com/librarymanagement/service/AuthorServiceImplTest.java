package com.librarymanagement.service;

import com.librarymanagement.entity.Author;
import com.librarymanagement.entity.Book;
import com.librarymanagement.repository.AuthorRepo;
import com.librarymanagement.repository.BookRepo;
import com.librarymanagement.serviceImpl.AuthorServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.stubbing.Answer;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

public class AuthorServiceImplTest {

    @Mock
    private AuthorRepo authorRepo;

    @Mock
    private BookRepo bookRepo;

    @InjectMocks
    private AuthorServiceImpl authorService;

    Author author1;
    Author author2;
    Book bookObj1;
    Book bookObj2;
    List<Author> authorList = new ArrayList<>();

    List<Book> bookList = new ArrayList<>();

    @BeforeEach
    void setUp() {

        MockitoAnnotations.openMocks(this);
        author1 = new Author(123L,"Robbin Hood", LocalDate.of(2017, 1, 13));
        author2 = new Author(456L,"Rohit Sharma", LocalDate.of(2000, 5, 10));
        authorList.add(author1);
        authorList.add(author2);
        bookObj1 = new Book(1234567890L, "The 5 AM Club",LocalDate.of(2017, 1, 13),2345.90, List.of(author1));
        bookObj2 = new Book(12345678L, "Power of Your Subconscious",LocalDate.of(2019, 1, 13),2341.90, authorList);
        bookList.add(bookObj1);
        bookList.add(bookObj2);
    }


    @Test
    void testSaveAuthor() {
        Author authorToSave = author1;
        Author savedAuthor = author1;

        when(authorRepo.save(authorToSave)).thenReturn(savedAuthor);

        Author result = authorService.save(authorToSave);

        assertEquals(savedAuthor, result);
        verify(authorRepo, times(1)).save(authorToSave);
    }

    @Test
    void testFindAuthorExistsOrNot() {
        Author authorToFind = author1;
        when(authorRepo.findByAuthorDobAndName(authorToFind.getAuthorDob(), authorToFind.getAuthorName()))
                .thenReturn(Optional.of(authorToFind));

        boolean exists = authorService.findAuthorExistsOrNot(authorToFind);

        assertEquals(true, exists);
        verify(authorRepo, times(1)).findByAuthorDobAndName(authorToFind.getAuthorDob(), authorToFind.getAuthorName());
    }

    @Test
    void testFindAuthorIdExistsOrNot() {
        Long authorId = 1L;
        Author authorToFind = author1;
        when(authorRepo.findByAuthorId(authorId)).thenReturn(Optional.of(authorToFind));

        Optional<Author> result = authorService.findAuthorIdExistsOrNot(authorId);

        assertEquals(Optional.of(authorToFind), result);
        verify(authorRepo, times(1)).findByAuthorId(authorId);
    }


    @Test
    void testGetBooksByAuthor() {
        Long authorId = 123L;
        Author author = author1;
        List<Book> expectedBooks = Arrays.asList(bookObj1,bookObj2);

        when(bookRepo.findBooksByAuthorId(authorId)).thenReturn(expectedBooks);

        List<Book> result = authorService.getBooksByAuthor(author);

        assertEquals(expectedBooks, result);
        verify(bookRepo, times(1)).findBooksByAuthorId(authorId);
    }
}
