package com.librarymanagement.service;

import com.librarymanagement.entity.Author;
import com.librarymanagement.entity.Book;
import com.librarymanagement.repository.AuthorRepo;
import com.librarymanagement.repository.BookRepo;
import com.librarymanagement.serviceImpl.BookServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.time.LocalDate;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class BookServiceImplTest {

    @Mock
    private BookRepo bookRepo;

    @Mock
    private AuthorRepo authorRepo;

    @InjectMocks
    private BookServiceImpl bookService;

    Author author1;
    Author author2;
    Book bookObj1;
    Book bookObj2;
    List<Author> authorList = new ArrayList<>();

    List<Book> bookList = new ArrayList<>();

    @BeforeEach
    void setUp() {

        MockitoAnnotations.openMocks(this);
        author1 = new Author(123L,"Robbin Hood", LocalDate.of(2017, 1, 13));
        author2 = new Author(456L,"Rohit Sharma", LocalDate.of(2000, 5, 10));
        authorList.add(author1);
        authorList.add(author2);
        bookObj1 = new Book(1234567890L, "The 5 AM Club",LocalDate.of(2017, 1, 13),2345.90, List.of(author1));
        bookObj2 = new Book(12345678L, "Power of Your Subconscious",LocalDate.of(2019, 1, 13),2341.90, authorList);
        bookList.add(bookObj1);
        bookList.add(bookObj2);
    }

    @Test
    void saveBook_shouldReturnSavedBook() {
        Book book = bookObj1;
        when(bookRepo.save(book)).thenReturn(book);

        Book savedBook = bookService.saveBook(book);

        assertSame(book, savedBook);
        verify(bookRepo, times(1)).save(book);
    }

    @Test
    void findBookExistsOrNot_existingBook_shouldReturnTrue() {
        Book book = bookObj1;
        when(bookRepo.findBookExistsOrNot(book.getBookIsbn(), book.getTitle())).thenReturn(Optional.of(book));

        boolean exists = bookService.findBookExistsOrNot(book);

        assertTrue(exists);
        verify(bookRepo, times(1)).findBookExistsOrNot(book.getBookIsbn(), book.getTitle());
    }

    @Test
    void findBookExistsOrNot_nonExistingBook_shouldReturnFalse() {
        Book book = bookObj2;
        when(bookRepo.findBookExistsOrNot(book.getBookIsbn(), book.getTitle())).thenReturn(Optional.empty());

        boolean exists = bookService.findBookExistsOrNot(book);

        assertFalse(exists);
        verify(bookRepo, times(1)).findBookExistsOrNot(book.getBookIsbn(), book.getTitle());
    }

    @Test
    void findAuthorIdExistsOrNotForBook_allAuthorsExist_shouldReturnFalse() {
        Author author1 = new Author();
        author1.setAuthorId(1L);
        Author author2 = new Author();
        author2.setAuthorId(2L);
        Book book = new Book();
        book.setAuthors(Arrays.asList(author1, author2));

        when(authorRepo.findByAuthorId(1L)).thenReturn(Optional.of(author1));
        when(authorRepo.findByAuthorId(2L)).thenReturn(Optional.of(author2));

        boolean exists = bookService.findAuthorIdExistsOrNotFOrBook(book);

        assertFalse(exists);
        verify(authorRepo, times(1)).findByAuthorId(1L);
        verify(authorRepo, times(1)).findByAuthorId(2L);
    }

    @Test
    void findAuthorIdExistsOrNotForBook_someAuthorDoesNotExist_shouldReturnTrue() {
        Author author1 = new Author();
        author1.setAuthorId(1L);
        Author author2 = new Author();
        author2.setAuthorId(2L);
        Book book = new Book();
        book.setAuthors(Arrays.asList(author1, author2));

        when(authorRepo.findByAuthorId(1L)).thenReturn(Optional.of(author1));
        when(authorRepo.findByAuthorId(2L)).thenReturn(Optional.empty());

        boolean exists = bookService.findAuthorIdExistsOrNotFOrBook(book);

        assertTrue(exists);
        verify(authorRepo, times(1)).findByAuthorId(1L);
        verify(authorRepo, times(1)).findByAuthorId(2L);
    }

    @Test
    void getBookByIsbn_existingIsbn_shouldReturnBook() {
        long isbn = 1234567890L;
        Book book = bookObj1;
        when(bookRepo.findByBookIsbn(isbn)).thenReturn(Optional.of(book));

        Optional<Book> result = bookService.getBookByIsbn(isbn);

        assertTrue(result.isPresent());
        assertSame(book, result.get());
        verify(bookRepo, times(1)).findByBookIsbn(isbn);
    }

    @Test
    void getBookByIsbn_nonExistingIsbn_shouldReturnEmptyOptional() {
        long isbn = 1234567890L;
        when(bookRepo.findByBookIsbn(isbn)).thenReturn(Optional.empty());

        Optional<Book> result = bookService.getBookByIsbn(isbn);

        assertFalse(result.isPresent());
        verify(bookRepo, times(1)).findByBookIsbn(isbn);
    }

    @Test
    void updateBookPriceAndDate_existingIsbn_shouldReturnUpdatedBook() {
        long isbn = 1234567890L;
        Book existingBook = new Book();
        existingBook.setBookIsbn(isbn);
        Book updatedBook = new Book();
        updatedBook.setPrice(19.99);
        updatedBook.setPublishDate(LocalDate.of(2017, 1, 13));

        when(bookRepo.findByBookIsbn(isbn)).thenReturn(Optional.of(existingBook));
        when(bookRepo.save(existingBook)).thenReturn(existingBook);

        Book result = bookService.updateBookPriceAndDate(isbn, updatedBook);

        assertSame(existingBook, result);
        assertEquals(19.99, result.getPrice());
        assertEquals(LocalDate.of(2017, 1, 13), result.getPublishDate());
        verify(bookRepo, times(1)).findByBookIsbn(isbn);
        verify(bookRepo, times(1)).save(existingBook);
    }

}
