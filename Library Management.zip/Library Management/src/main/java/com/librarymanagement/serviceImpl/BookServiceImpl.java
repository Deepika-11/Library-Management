package com.librarymanagement.serviceImpl;

import com.librarymanagement.entity.Author;
import com.librarymanagement.entity.Book;
import com.librarymanagement.repository.AuthorRepo;
import com.librarymanagement.repository.BookRepo;
import com.librarymanagement.service.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

@Service
public class BookServiceImpl implements BookService {

    @Autowired
    BookRepo bookRepo;

    @Autowired
    AuthorRepo authorRepo;

    @Override
    public Book saveBook(Book book) {
        return bookRepo.save(book);
    }

    @Override
    public boolean findBookExistsOrNot(Book book) {
        Optional<Book> optionalBook = bookRepo.findBookExistsOrNot(book.getBookIsbn(),book.getTitle());
        return optionalBook.isPresent() ? true: false;
    }

    public boolean findAuthorIdExistsOrNotFOrBook(Book book){
        for(Author a : book.getAuthors()){
            Optional<Author> optionalAuthor = authorRepo.findByAuthorId(a.getAuthorId());
            if(!optionalAuthor.isPresent()){
                return true;
            }
        }
        return false;
    }

    @Override
    public Optional<Book> getBookByIsbn(Long isbn) {
        return bookRepo.findByBookIsbn(isbn);
    }

    @Override
    public Book updateBookPriceAndDate(Long isbn, Book book) {
        Book book1 = bookRepo.findByBookIsbn(isbn).get();
        book1.setPrice(book.getPrice());
        book1.setPublishDate(book.getPublishDate());
        book1.setAuthors(book.getAuthors());
        return bookRepo.save(book1);
    }

    @Override
    @Transactional
    public String deleteBook(Book book) {
        book.getAuthors().removeAll(book.getAuthors());
        bookRepo.delete(book);
        return "Book deleted successfully";
    }


}
