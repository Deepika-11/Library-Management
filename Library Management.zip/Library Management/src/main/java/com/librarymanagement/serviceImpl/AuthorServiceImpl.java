package com.librarymanagement.serviceImpl;

import com.librarymanagement.entity.Author;
import com.librarymanagement.entity.Book;
import com.librarymanagement.repository.AuthorRepo;
import com.librarymanagement.repository.BookRepo;
import com.librarymanagement.service.AuthorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

@Service
public class AuthorServiceImpl implements AuthorService {


    @Autowired
    AuthorRepo authorRepo;

    @Autowired
    BookRepo bookRepo;

    @Override
    public Author save(Author author) {
        return authorRepo.save(author);
    }

    @Override
    public boolean findAuthorExistsOrNot(Author author) {
        Optional<Author> optionalAuthor = authorRepo.findByAuthorDobAndName(author.getAuthorDob(), author.getAuthorName());
        System.out.println(optionalAuthor);
        return optionalAuthor.isPresent() ? true : false;
    }

    @Override
    public Optional<Author> findAuthorIdExistsOrNot(Long id) {
        return authorRepo.findByAuthorId(id);
    }


    @Override
    @Transactional
    public String deleteAuthor(Long authorId) {
        List<Long> bookIds = bookRepo.findBooksByAuthor(authorId);
        Author authorToRemove = authorRepo.findByAuthorId(authorId).get();
        for (Long bookId : bookIds) {
            Optional<Book> book = bookRepo.findByBookIsbn(bookId);
            if (book.isPresent()) {
                if(book.get().getAuthors().size() == 1){
                    book.get().getAuthors().remove(authorToRemove);
                    bookRepo.delete(book.get());
                }
                else {
                    book.get().getAuthors().remove(authorToRemove);
                }
            }
        }
        authorRepo.deleteByAuthorId(authorId);
        return "Author detail deleted successfully";
    }


    public List<Book> getBooksByAuthor(Author author) {
        List<Book> list = bookRepo.findBooksByAuthorId(author.getAuthorId());
        return list;
    }


}
