package com.librarymanagement.controller;

import com.librarymanagement.entity.Book;
import com.librarymanagement.exceptionHandling.AuthorExistsOrNotException;
import com.librarymanagement.exceptionHandling.BookIsbnExistsOrNot;
import com.librarymanagement.serviceImpl.BookServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequestMapping("/books")
public class BookController {

    /*
    -> Creating a new book with details: ISBN, Title, Publish Date, Price and its author(s)
    -> Retrieving a book based on the ISBN
    -> Updating the details of an existing book
    -> Deleting an existing book
     */

    @Autowired
    BookServiceImpl bookService;

    @PostMapping("/save")
    public ResponseEntity<?> saveBookDetails(@RequestBody Book book){
        boolean ans = bookService.findBookExistsOrNot(book);
        boolean checkAuthorId = bookService.findAuthorIdExistsOrNotFOrBook(book);
        if(checkAuthorId)
            return new AuthorExistsOrNotException("The given author id is invalid").handleAuthorsException();
        return !ans ? new ResponseEntity<>(bookService.saveBook(book), HttpStatus.CREATED):
                new BookIsbnExistsOrNot("Book already exists.").handleBooksException();
    }

    @GetMapping("/get/{isbn}")
    public ResponseEntity<?> getBookDetails(@PathVariable("isbn") Long isbn){
        Optional<Book> book = bookService.getBookByIsbn(isbn);
        if(book.isPresent())
            return new ResponseEntity<>(book, HttpStatus.OK);
        throw new BookIsbnExistsOrNot();
    }

   @PutMapping("/update/{isbn}")
    public ResponseEntity<?> updateBookDetails(@PathVariable("isbn") Long isbn, @RequestBody Book book){
        Optional<Book> b = bookService.getBookByIsbn(isbn);
        if(b.isPresent()) return new ResponseEntity<>(bookService.updateBookPriceAndDate(isbn, book), HttpStatus.OK);
        throw new BookIsbnExistsOrNot();
    }

    @DeleteMapping("/delete/{isbn}")
    public ResponseEntity<?> deleteBookByIsbn(@PathVariable("isbn") Long isbn) {
        Optional<Book> optionalBook = bookService.getBookByIsbn(isbn);
        if(!optionalBook.isPresent()) throw new BookIsbnExistsOrNot();
        return new ResponseEntity<>(bookService.deleteBook(optionalBook.get()), HttpStatus.OK);
    }


}
