package com.librarymanagement.controller;
import com.librarymanagement.entity.Author;
import com.librarymanagement.exceptionHandling.AuthorExistsOrNotException;
import com.librarymanagement.serviceImpl.AuthorServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequestMapping("/authors")
public class AuthorController {

   /* -> Creating a new author with details: ID, Name
    -> Retrieving an author based on ID
    -> Deleting an existing author
    -> Listing all books by an author*/


    @Autowired
    AuthorServiceImpl authorServiceImpl;

    @PostMapping("/save")
    public ResponseEntity<?> saveAuthorDetails(@RequestBody Author author){
        boolean optionalAuthor = authorServiceImpl.findAuthorExistsOrNot(author);
        return (optionalAuthor) ? new AuthorExistsOrNotException("The author detail is already present in the database").handleAuthorsException() :
        new ResponseEntity<>(authorServiceImpl.save(author), HttpStatus.CREATED);
    }

    @GetMapping("/get/{id}")
    public ResponseEntity<?> getAuthorById(@PathVariable("id") Long id){
        Optional<Author> optionalAuthor = authorServiceImpl.findAuthorIdExistsOrNot(id);
        if(!optionalAuthor.isPresent()) throw new AuthorExistsOrNotException();
        return new ResponseEntity<>(optionalAuthor, HttpStatus.OK);
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<?> deleteAuthorById(@PathVariable("id") Long id){
        Optional<Author> optionalAuthor = authorServiceImpl.findAuthorIdExistsOrNot(id);
        if(!optionalAuthor.isPresent()) throw new AuthorExistsOrNotException();
        return new ResponseEntity<>(authorServiceImpl.deleteAuthor(id),HttpStatus.OK);
    }

    @GetMapping("/get/list/{id}")
    public ResponseEntity<?> getAllBookByAuthor(@PathVariable("id") Long id){
        Optional<Author> optionalAuthor = authorServiceImpl.findAuthorIdExistsOrNot(id);
        return optionalAuthor.isPresent() ?
                new ResponseEntity<>(authorServiceImpl.getBooksByAuthor(optionalAuthor.get()).isEmpty()
                        ? "The Author books not available in database" : authorServiceImpl.getBooksByAuthor(optionalAuthor.get()), HttpStatus.OK)
                :new AuthorExistsOrNotException("Author id doesn't exists").handleAuthorsException();
    }

}
