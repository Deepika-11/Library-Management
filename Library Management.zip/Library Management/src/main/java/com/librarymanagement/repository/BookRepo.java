package com.librarymanagement.repository;

import com.librarymanagement.entity.Author;
import com.librarymanagement.entity.Book;
import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;

@Repository
public interface BookRepo extends JpaRepository<Book, Long> {

    @Query("SELECT b FROM Book b JOIN b.authors a WHERE a.authorId = :authorId")
    List<Book> findBooksByAuthorId(@Param("authorId") Long authorId);

    @Query("SELECT b FROM Book b WHERE b.bookIsbn = :bookIsbn and b.title = :title")
    Optional<Book> findBookExistsOrNot(@Param("bookIsbn") Long bookIsbn, @Param("title") String title);

    Optional<Book> findByBookIsbn(Long isbn);

    @Query("SELECT b.bookIsbn FROM Book b JOIN b.authors a WHERE a.authorId = :authorId")
    List<Long> findBooksByAuthor(Long authorId);
}
