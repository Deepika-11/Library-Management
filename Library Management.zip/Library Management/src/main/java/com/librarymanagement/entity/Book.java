package com.librarymanagement.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;
import java.util.List;

@Getter
@ToString
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class Book {

    @Id
    private Long bookIsbn;
    private String title;
    private LocalDate publishDate;
    private Double price;
    @ManyToMany(fetch = FetchType.LAZY,cascade = CascadeType.REMOVE)
    @JoinTable(
            name = "book_author",
            joinColumns = @JoinColumn(name = "bookIsbn"),
            inverseJoinColumns = @JoinColumn(name = "authorId")
    )
    private List<Author> authors;

}
