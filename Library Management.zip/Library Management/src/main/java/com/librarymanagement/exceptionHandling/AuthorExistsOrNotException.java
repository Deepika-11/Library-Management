package com.librarymanagement.exceptionHandling;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

public class AuthorExistsOrNotException extends RuntimeException{

    public AuthorExistsOrNotException(String msg) {
        super(msg);
    }

    public AuthorExistsOrNotException() {
    }

    public ResponseEntity<?> handleAuthorsException() {
        ErrorResponse errorResponse = new ErrorResponse();
        errorResponse.setErrorCode("404");
        errorResponse.setErrorResponse(super.getMessage());
        return new ResponseEntity<>(errorResponse, HttpStatus.NOT_FOUND);
    }
}
