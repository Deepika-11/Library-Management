package com.librarymanagement.exceptionHandling;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@ControllerAdvice
@ResponseStatus
public class GlobalExceptionHandler extends ResponseEntityExceptionHandler {

    @ExceptionHandler({AuthorExistsOrNotException.class})
    public ResponseEntity<ErrorResponse> handleAuthorException() {
        ErrorResponse errorResponse = new ErrorResponse();
        errorResponse.setErrorCode("404");
        errorResponse.setErrorResponse("The given author is not found. So necessary operation is not able to do.");
        return new ResponseEntity<>(errorResponse, HttpStatus.NOT_FOUND);
    }


    @ExceptionHandler({BookIsbnExistsOrNot.class})
    public ResponseEntity<ErrorResponse> handleBookException() {
        ErrorResponse errorResponse = new ErrorResponse();
        errorResponse.setErrorCode("404");
        errorResponse.setErrorResponse("The given book is not found. So necessary operation is not able to do.");
        return new ResponseEntity<>(errorResponse, HttpStatus.NOT_FOUND);
    }

}
