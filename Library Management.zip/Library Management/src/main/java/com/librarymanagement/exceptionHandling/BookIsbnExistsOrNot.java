package com.librarymanagement.exceptionHandling;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

public class BookIsbnExistsOrNot extends RuntimeException{

    public BookIsbnExistsOrNot(){

    }
    public BookIsbnExistsOrNot(String msg) {
        super(msg);
    }

    public ResponseEntity<ErrorResponse> handleBooksException() {
        ErrorResponse errorResponse = new ErrorResponse();
        errorResponse.setErrorCode("404");
        errorResponse.setErrorResponse(super.getMessage());
        return new ResponseEntity<>(errorResponse, HttpStatus.NOT_FOUND);
    }

}
