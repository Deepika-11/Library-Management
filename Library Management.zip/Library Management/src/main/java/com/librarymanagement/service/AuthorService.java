package com.librarymanagement.service;

import com.librarymanagement.entity.Author;

import java.util.Optional;

public interface AuthorService  {

    Author save(Author author);

    boolean findAuthorExistsOrNot(Author author);

    Optional<Author> findAuthorIdExistsOrNot(Long id);

    String deleteAuthor(Long id);
}
