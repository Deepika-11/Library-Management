package com.librarymanagement.service;

import com.librarymanagement.entity.Book;

import java.util.Optional;

public interface BookService{
    Book saveBook(Book book);

    boolean findBookExistsOrNot(Book book);

    Optional<Book> getBookByIsbn(Long isbn);

    Book updateBookPriceAndDate(Long isbn, Book book);

    String deleteBook(Book book);
}
